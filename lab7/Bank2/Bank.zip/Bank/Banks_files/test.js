/* jshint esversion: 6*/
/*** eslint-disable */
(function () {
        'use strict';

        let data = {
            statement: "",
            word: "",
            arr: [],
            subject: "",
            name1:"",
            name2:""
        };

        describe("General Test", function () {
            context("Testing the methods on the account: ", function () {

                beforeEach(function () {
                    data.balance =  100;
                    data.withdraw = 50;
                });




            });

        });


    }
)();