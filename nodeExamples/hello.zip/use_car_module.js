const car=require('./car_module');

car.drive();
car.drive();
car.turn(20);
car.break();

